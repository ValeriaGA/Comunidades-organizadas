$(document).ready(function() {

  var modal = document.getElementById('modal-wrapper');
  window.onclick = function(event) {
      if (event.target == modal) {
          modal.style.display = "none";
      }
  }
  
  
    //Fixing jQuery Click Events for the iPad
    var ua = navigator.userAgent,
    event = (ua.match(/iPad/i)) ? "touchstart" : "click";
    if ($('.table').length > 0) {
        $('.table .header').on(event, function() {
            $(this).toggleClass("active", "").nextUntil('.header').css('display', function(i, v) {
            return this.style.display === 'table-row' ? 'none' : 'table-row';
            });
        });
    }


  });