@extends('report.layouts.edit_master')

@section('page-title', 'Servicio')

@section('page-desc', 'Editar reporte de servicio')

@section('form', '/servicio')

@section('tabs')
    
@endsection

@section('tab-content')
    
@endsection

@section('details')
    
@endsection