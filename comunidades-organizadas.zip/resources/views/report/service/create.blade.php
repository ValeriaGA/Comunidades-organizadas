@extends('report.layouts.create_master')

@section('page-title', 'Reporte Servicio')

@section('page-desc', 'Agregar reporte de servicio')

@section('form', '/servicio')

@section('tabs')
    
@endsection

@section('tab-content')
    
@endsection

@section('details')
    
@endsection