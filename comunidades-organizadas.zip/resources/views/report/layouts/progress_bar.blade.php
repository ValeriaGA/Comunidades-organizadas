<div class="form-group">
    <div class="col-sm-12">
        <div class="progress">
            <div class="progress-bar bg-success " role="progressbar" aria-valuenow="{{$progress}}" aria-valuemin="0" aria-valuemax="0" style="width:{{$progress}}%;"></div>
        </div>
    </div>
</div>