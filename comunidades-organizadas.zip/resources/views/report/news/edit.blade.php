@extends('report.layouts.edit_master')

@section('page-title', 'Noticia')

@section('page-desc', 'Editar noticia')

@section('form', '/noticia')

@section('tabs')
    
@endsection

@section('tab-content')
    
@endsection

@section('details')
    
@endsection