@extends('report.layouts.show_master')

@section('tabs')
    
@endsection

@section('tab-content')
    
@endsection