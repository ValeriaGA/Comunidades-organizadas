@extends('report.layouts.create_master')

@section('page-title', 'Noticia')

@section('page-desc', 'Agregar noticia')

@section('form', '/noticia')

@section('tabs')
    
@endsection

@section('tab-content')
    
@endsection

@section('details')
    
@endsection