<div class="col-md-12 col-lg-12 col-sm-12">
    <div class="white-box">
        <div class="comment-center p-t-10">
			<?php $__currentLoopData = $security_reports; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $report): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	            <div class="comment-body">
				    <div class="mail-contnet">
				    	<div class="row">
				    		<div class="col-md-4">
					    		<?php echo $__env->make('home.layouts.evidence', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
					    	</div>
					    	<div class="col-md-8">
					    		<h5><?php echo e($report->title); ?></h5>
						        <span class="time"><b>Fecha y Hora :</b> <?php echo e($report->date); ?> <?php echo e($report->time); ?></span>
						        <br/>
						        <span class="time"><b>Lugar :</b> <?php echo e($report->communityGroup->name); ?></span>
						        <br/>
						        <span class="time"><b>Tipo :</b> <?php echo e($report->subCatReport->name); ?></span>
						        <br/>
						        <span id="likes_lbl_<?php echo e($report->id); ?>" class="time" value="<?php echo e(count($report->like)); ?>"><b>Agradecimientos :</b> <?php echo e(count($report->like)); ?></span>
						        <br/>
						        <span class="mail-desc"> <?php echo e($report->description); ?> </span>
						        <br/>
						        <span class="label label-success"><?php echo e($report->state->name); ?></span>
					    	</div>
				    	</div>
				    	<br />
				        <div class="row">
                        	<?php echo $__env->make('layouts.action_buttons', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
				        </div>
					</div>
				</div>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <?php echo e($security_reports->links()); ?>

    </div>
</div>
