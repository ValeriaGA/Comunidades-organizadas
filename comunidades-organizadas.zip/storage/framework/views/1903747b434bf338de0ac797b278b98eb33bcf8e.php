<?php $__env->startSection('js'); ?>
<script>
        // Themes begin
        am4core.useTheme(am4themes_animated);
        // Themes end
        
        window.onload = function() {
        
        /**
         * This demo uses our own method of determining user's location
         * It is not public web service that you can use
         * You'll need to find your own. We recommend http://www.maxmind.com
         */
        
        
          var defaultMap = "costaRicaLow";
        
          var countryMaps = {
            "AL": [ "albaniaLow" ],
            "DZ": [ "algeriaLow" ],
            "AD": [ "andorraLow" ],
            "AO": [ "angolaLow" ],
            "AR": [ "argentinaLow" ],
            "AM": [ "armeniaLow" ],
            "AU": [ "australiaLow" ],
            "AT": [ "austriaLow" ],
            "AZ": [ "azerbaijanLow" ],
            "BH": [ "bahrainLow" ],
            "BD": [ "bangladeshLow" ],
            "BY": [ "belarusLow" ],
            "BE": [ "belgiumLow" ],
            "BZ": [ "belizeLow" ],
            "BM": [ "bermudaLow" ],
            "BT": [ "bhutanLow" ],
            "BO": [ "boliviaLow" ],
            "BW": [ "botswanaLow" ],
            "BR": [ "brazilLow" ],
            "BN": [ "bruneiDarussalamLow" ],
            "BG": [ "bulgariaLow" ],
            "BF": [ "burkinaFasoLow" ],
            "BI": [ "burundiLow" ],
            "KH": [ "cambodiaLow" ],
            "CM": [ "cameroonLow" ],
            "CA": [ "canandaLow" ],
            "CV": [ "capeVerdeLow" ],
            "CF": [ "centralAfricanRepublicLow" ],
            "TD": [ "chadLow" ],
            "CL": [ "chileLow" ],
            "CN": [ "chinaLow" ],
            "CO": [ "colombiaLow" ],
            "CD": [ "congoDRLow" ],
            "CG": [ "congoLow" ],
            "CR": [ "costaRicaLow" ],
            "HR": [ "croatiaLow" ],
            "CZ": [ "czechRepublicLow" ],
            "DK": [ "denmarkLow" ],
            "DJ": [ "djiboutiLow" ],
            "DO": [ "dominicanRepublicLow" ],
            "EC": [ "ecuadorLow" ],
            "EG": [ "egyptLow" ],
            "SV": [ "elSalvadorLow" ],
            "EE": [ "estoniaLow" ],
            "SZ": [ "eswatiniLow" ],
            "FO": [ "faroeIslandsLow" ],
            "FI": [ "finlandLow" ],
            "FR": [ "franceLow" ],
            "GF": [ "frenchGuianaLow" ],
            "GE": [ "georgiaLow" ],
            "DE": [ "germanyLow" ],
            "GR": [ "greeceLow" ],
            "GL": [ "greenlandLow" ],
            "GN": [ "guineaLow" ],
            "HN": [ "hondurasLow" ],
            "HK": [ "hongKongLow" ],
            "HU": [ "hungaryLow" ],
            "IS": [ "icelandLow" ],
            "IN": [ "indiaLow" ],
            "GB": [ "ukLow" ],
            "IE": [ "irelandLow" ],
            "IL": [ "israelLow" ],
            "PS": [ "palestineLow" ],
            "MT": [ "italyLow" ],
            "SM": [ "italyLow" ],
            "VA": [ "italyLow" ],
            "IT": [ "italyLow" ],
            "JP": [ "japanLow" ],
            "MX": [ "mexicoLow" ],
            "RU": [ "russiaCrimeaLow" ],
            "KR": [ "southKoreaLow" ],
            "ES": [ "spainLow" ],
            "US": [ "usaAlbersLow" ]
          };
          
          // calculate which map to be used
          var currentMap = defaultMap;
          var title = "Costa Rica";
        
          
          // Create map instance
          var chart = am4core.create("chartdiv", am4maps.MapChart);
          
          chart.titles.create().text = title;

         var count_per_province = <?php echo json_encode($count_per_province)?>;
        
          // Set map definition
          chart.geodataSource.url = document.getElementById('mapLocation').value + "/" + currentMap + ".json";
          chart.geodataSource.events.on("parseended", function(ev) {
            var data = [];
            for(var i = 0; i < ev.target.data.features.length; i++) {
              
              data.push({
                id: ev.target.data.features[i].id,
                value: count_per_province[ev.target.data.features[i].id - 1][1]
               
              })
        
            }
            polygonSeries.data = data;
          })
        
          // Set projection
          chart.projection = new am4maps.projections.Miller();
        
          // Create map polygon series
          var polygonSeries = chart.series.push(new am4maps.MapPolygonSeries());
        
          //Set min/max fill color for each area
          polygonSeries.heatRules.push({
            property: "fill",
            target: polygonSeries.mapPolygons.template,
            min: chart.colors.getIndex(1).brighten(1),
            max: chart.colors.getIndex(1).brighten(-0.3)
          });
        
          // Make map load polygon data (state shapes and names) from GeoJSON
          polygonSeries.useGeodata = true;
        
          // Set up heat legend
          let heatLegend = chart.createChild(am4maps.HeatLegend);
          heatLegend.series = polygonSeries;
          heatLegend.align = "right";
          heatLegend.width = am4core.percent(25);
          heatLegend.marginRight = am4core.percent(4);
          heatLegend.minValue = 0;
          heatLegend.maxValue = 40000000;
        
          // Set up custom heat map legend labels using axis ranges
          var minRange = heatLegend.valueAxis.axisRanges.create();
          minRange.value = heatLegend.minValue;
          minRange.label.text = "Pocos";
          var maxRange = heatLegend.valueAxis.axisRanges.create();
          maxRange.value = heatLegend.maxValue;
          maxRange.label.text = "Muchos";
        
          // Blank out internal heat legend value axis labels
          heatLegend.valueAxis.renderer.labels.template.adapter.add("text", function(labelText) {
            return "";
          });
        
          // Configure series tooltip
          var polygonTemplate = polygonSeries.mapPolygons.template;
          polygonTemplate.tooltipText = "{name}: {value}";
        
          // Create hover state and set alternative fill color
          var hs = polygonTemplate.states.create("hover");
          hs.properties.fill = chart.colors.getIndex(1).brighten(-0.5);
          
        
        
        
        };
    </script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('stats_content'); ?>
    <input type="hidden" id="mapLocation" value="<?php echo e(asset('json')); ?>">
    <div class="row">
        <div class="col-md-10">
          <div class="white-box  analytics-info">
              <h2>Número de Comunidades por Provincia</h2>
              <br/>
              <br/>
            <div id="chartdiv"></div>
          </div>
        </div>
    </div>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('statistics.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>