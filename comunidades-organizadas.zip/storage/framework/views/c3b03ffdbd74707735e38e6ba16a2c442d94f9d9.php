<?php $__env->startSection('js'); ?>
  <script src="<?php echo e(asset('js/timeStatisticsControl.js')); ?>"></script>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('stats_content'); ?>


<!--row -->
<div class="row" >
    <div class="col-sm-12">
      <div class="white-box" style="height: 400px;">
          <h3 class="box-title">Filtros</h3>
        
        <form method="post" action="/statistics/tiempo" enctype="multipart/form-data">
          <?php echo e(csrf_field()); ?>

          <div class="col-sm-2">
            Filtrar por año:
            <br/>
            <br/>
            <select class="form-control" style="background-color: white; width:100px;" name="date">

              <?php for($i = 0; $i < 10; ++$i): ?>
                <?php if(($date - $i) == $selectedDate): ?>
                  <option value="<?php echo e($date - $i); ?>" selected><?php echo e($date - $i); ?></option>
                <?php else: ?>
                <option value="<?php echo e($date - $i); ?>"><?php echo e($date - $i); ?></option>
                <?php endif; ?> 
              <?php endfor; ?>
            </select>
          </div>

          <div class="col-sm-2">
            Personas que reportortaron:
            <br/>
            <br/>
            <label style="display: inline;">Sexo</label>
            <select class="form-control" style="background-color: white; width:150px; display:inline;" name="gender">

              <?php if($selectedGender == ""): ?>
                <option value="" selected>Todos</option>
              <?php else: ?> 
                <option value="">Todos</option>
              <?php endif; ?>

              <?php $__currentLoopData = $genders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gender): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                <?php if($gender -> name == $selectedGender): ?>
                  <option value="<?php echo e($gender -> name); ?>" selected><?php echo e($gender -> name); ?></option> 
                <?php else: ?>
                  <option value="<?php echo e($gender -> name); ?>"><?php echo e($gender -> name); ?></option> 
                <?php endif; ?>

              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 

            </select>

            <br/>
            <br/>
            <label style="display: inline;">Procedencia</label>
            <select class="form-control" style="background-color: white; width:150px;" name="procedence">

                <?php if($selectedProcedence == "Ambos"): ?>
                  <option value="Ambos" selected>Ambos</option> 
                  <option value="Nacionales">Nacionales</option> 
                  <option value="Extranjeros">Extranjeros</option>

                <?php elseif($selectedProcedence == "Nacionales"): ?>
                  <option value="Ambos">Ambos</option> 
                  <option value="Nacionales" selected>Nacionales</option> 
                  <option value="Extranjeros">Extranjeros</option>

                <?php else: ?> 
                  <option value="Ambos">Ambos</option> 
                  <option value="Nacionales">Nacionales</option> 
                  <option value="Extranjeros" selected>Extranjeros</option>

                <?php endif; ?>
            </select>
          
          </div>

          <div class="col-sm-8">
            Grupo de Comunidades:
            <br/>
            <br/>
            <div style="margin-top: 25px; margin-left: 0px; display:inline;">
                <label >Provincia</label>
                
                <select id="provinces" style="width:110px; display:inline;" class="form-control" name="province">
                  
                  <?php $__currentLoopData = $provinces; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($item -> id == $selectedItems['selectedProvince'] -> id): ?>
                      <option value="<?php echo e($item -> id); ?>" selected><?php echo e($item -> name); ?></option>
                    <?php else: ?>
                      <option value="<?php echo e($item -> id); ?>"><?php echo e($item -> name); ?></option>
                    <?php endif; ?>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                       
                
                </select>
            </div>

              <div style="margin-top: 25px; margin-left: 10px; display:inline;">
                  <label >Cantón</label>
                  <input name="selectedCanton" type="hidden" value="<?php echo e($selectedItems['selectedCanton']); ?>"/>
                  <select id="cantons" style="width:110px; display:inline;" class="form-control"  name="canton" >
                    <?php $__currentLoopData = $selectedItems['selectedProvince'] -> canton() -> get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <?php if($item -> id == $selectedItems['selectedCanton'] -> id): ?>
                        <option value="<?php echo e($item -> id); ?>" selected><?php echo e($item -> name); ?></option>
                      <?php else: ?>
                        <option value="<?php echo e($item -> id); ?>"><?php echo e($item -> name); ?></option>
                      <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                  </select>
              </div>


              <div style="margin-top: 25px; margin-left: 10px; display:inline;">
                  <label >Distrito</label>
                  
                  <select id="districts" style="width:110px; display:inline;" class="form-control" name="district">
                    <?php $__currentLoopData = $selectedItems['selectedCanton'] -> district() -> get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <?php if($item -> id == $selectedItems['selectedDistrict'] -> id): ?>
                        <option value="<?php echo e($item -> id); ?>" selected><?php echo e($item -> name); ?></option>
                      <?php else: ?>
                        <option value="<?php echo e($item -> id); ?>"><?php echo e($item -> name); ?></option>
                      <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </select>
              </div>
                    

              <br/>
              <br/>
              <div style="margin-top: 25px; margin-left: 50px; display:inline; margin-top: 10px;">
                  <label>Comunidad</label>
                  
                  <select id="communities" style="width:180px; display:inline;" class="form-control"  name="community">
                    <?php if(!is_null($selectedItems['selectedCommunity'])): ?>
                      <?php $__currentLoopData = $selectedItems['selectedDistrict'] -> community() -> get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($item -> id == $selectedItems['selectedCommunity'] -> id): ?>
                          <option value="<?php echo e($item -> id); ?>" selected><?php echo e($item -> name); ?></option>
                        <?php else: ?>
                          <option value="<?php echo e($item -> id); ?>"><?php echo e($item -> name); ?></option>
                      <?php endif; ?>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php else: ?>
                        <option value="" selected>Sin Comunidades</option>
                    <?php endif; ?>

                  </select>
                  
              </div>

              <div style="margin-top: 25px; margin-left: 50px; display:inline; margin-top: 10px;">
                  <label>Grupo</label>
                  
                  <select id="communityGroups" style="width:180px; display:inline;" class="form-control"  name="group">

                      <?php if(!is_null($selectedItems['selectedCommunity']) && !is_null($selectedItems['selectedGroup'])): ?>

                        <?php $__currentLoopData = $selectedItems['selectedCommunity'] -> communityGroup() -> get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <?php if($item -> id == $selectedItems['selectedGroup'] -> id): ?>
                            <option value="<?php echo e($item -> id); ?>" selected><?php echo e($item -> name); ?></option>
                          <?php else: ?>
                            <option value="<?php echo e($item -> id); ?>"><?php echo e($item -> name); ?></option>
                        <?php endif; ?>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      
                    <?php else: ?>
                        <option value="" selected>Sin Grupos</option>
                    <?php endif; ?>

                  </select>
                  
              </div>
              <br/>
              <br/>

              <?php if($anyGroup == null): ?>
                <input type="checkbox" name="noCommunitiesCheckbox" value="1" style="margin-left: 150px;"> Utilizar cualquier Grupo
              <?php else: ?>
                <input type="checkbox" name="noCommunitiesCheckbox" value="1" style="margin-left: 150px;" checked> Utilizar cualquier Grupo
              <?php endif; ?>


          </div>
          <br/>
          <br/>
          <br/>
          <button class="btn btn-success" style="margin-top: 100px; margin-left:100px;">Actualizar</button>
        </form>
        
        </div>

         
      </div>
    </div>

<div class="row">
    <div class="col-md-12">
        <div class="white-box analytics-info">
        <h2>Cantidad de Reportes en el año <?php echo e($selectedDate); ?></h2>

        <div style="overflow:auto;">
        <div id="graph" style="width: 1500px;"></div>
        </div>

        <pre id="code" class="prettyprint linenums">
        var day_data = [
          {"elapsed": "Enero", "valor": <?php echo e((array_key_exists('January', $dic) ? $dic['January'] : 0)); ?> },
          {"elapsed": "Febrero", "valor": <?php echo e((array_key_exists('February', $dic) ? $dic['February'] : 0)); ?> },
          {"elapsed": "Marzo", "valor": <?php echo e((array_key_exists('March', $dic) ? $dic['March'] : 0)); ?> },
          {"elapsed": "Abril", "valor": <?php echo e((array_key_exists('April', $dic) ? $dic['April'] : 0)); ?> },
          {"elapsed": "Mayo", "valor": <?php echo e((array_key_exists('May', $dic) ? $dic['May'] : 0)); ?> },
          {"elapsed": "Junio", "valor": <?php echo e((array_key_exists('June', $dic) ? $dic['June'] : 0)); ?> },
          {"elapsed": "Julio", "valor": <?php echo e((array_key_exists('July', $dic) ? $dic['July'] : 0)); ?> },
          {"elapsed": "Agosto", "valor": <?php echo e((array_key_exists('August', $dic) ? $dic['August'] : 0)); ?> },
          {"elapsed": "Septiembre", "valor": <?php echo e((array_key_exists('September', $dic) ? $dic['September'] : 0)); ?> },
          {"elapsed": "Octubre", "valor": <?php echo e((array_key_exists('October', $dic) ? $dic['October'] : 0)); ?> },
          {"elapsed": "Noviembre", "valor": <?php echo e((array_key_exists('November', $dic) ? $dic['November'] : 0)); ?> },
          {"elapsed": "Diciembre", "valor": <?php echo e((array_key_exists('December', $dic) ? $dic['December'] : 0)); ?> }
        ];
        Morris.Line({
          element: 'graph',
          data: day_data,
          xkey: 'elapsed',
          ykeys: ['valor'],
          labels: ['valor'],
          parseTime: false
        });
        </pre>
      </div>
    </div>
</div>
 

    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('statistics.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>