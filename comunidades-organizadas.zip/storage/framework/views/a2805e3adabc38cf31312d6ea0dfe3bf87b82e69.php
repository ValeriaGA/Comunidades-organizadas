<?php $__env->startSection('stats_content'); ?>

<!--row -->
                <div class="row">
                    <div class="col-md-10">
                        <div class="white-box analytics-info">
                        <?php if($selectedStartDate == $selectedEndDate): ?>
                          <h2>Proporción de mujeres y hombres víctimas en el año <?php echo e($selectedStartDate); ?></h2>
                        <?php else: ?>
                          <h2>Proporción de mujeres y hombres víctimas entre <?php echo e($selectedStartDate); ?> y <?php echo e($selectedEndDate); ?></h2>
                        <?php endif; ?>

                        <a>Seleccione un delito:</a>
                        <form class="form-horizontal form-material" action="/statistics/genero"  method="post" enctype="multipart/form-data">
                        <?php echo e(csrf_field()); ?>

                          <select style="background-color: white;" name="delitos">
                            <?php $__currentLoopData = $types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                           
                              <?php if($selected_incident_name == $type -> name): ?>
                                <option name="<?php echo e($type->id); ?>" value="<?php echo e($type->id); ?>" selected><?php echo e($type->name); ?></option> 
                              <?php else: ?>
                                <option name="<?php echo e($type->id); ?>" value="<?php echo e($type->id); ?>"><?php echo e($type->name); ?></option> 
                              <?php endif; ?>
                            
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          </select>

                          <br/>
                          <br/>
                          <a>Seleccione un rango de años:</a>
                          <br/>
                          Desde:
                          <select style="background-color: white; width: 100px;" name="startYear">
                          <?php for($i = 0; $i < 10; ++$i): ?>
                            <?php if(($date - $i) == $selectedStartDate): ?>
                              <option value="<?php echo e($date - $i); ?>" selected><?php echo e($date - $i); ?></option>
                            <?php else: ?>
                            <option value="<?php echo e($date - $i); ?>"><?php echo e($date - $i); ?></option>
                            <?php endif; ?> 
                          <?php endfor; ?>
                          </select>

                          <br/>
                          <br/>
                          Hasta:
                          <select style="background-color: white; width:105px;" name="endYear">
                          <?php for($i = 0; $i < 10; ++$i): ?>
                            <?php if(($date - $i) == $selectedEndDate): ?>
                              <option value="<?php echo e($date - $i); ?>" selected><?php echo e($date - $i); ?></option>
                            <?php else: ?>
                            <option value="<?php echo e($date - $i); ?>"><?php echo e($date - $i); ?></option>
                            <?php endif; ?> 
                          <?php endfor; ?>
                          </select>
                          <div class="form-group">
                              <div class="col-sm-12">
                              <br/><button class="btn btn-success">Actualizar</button>
                              </div>
                          </div>
                                              
                         
                        </form>
                        <a  class="waves-effect"><?php echo e($selected_incident_name); ?></a><br>
                        <a  class="waves-effect">Total de incidentes: <?php echo e($total); ?></a>
                        <?php if($total== 0): ?>
                          <h3>No hay registros para este incidente</h3>
                        <?php else: ?>
                          <div id="graph"></div>
                        <pre id="code" class="prettyprint linenums">
                        Morris.Donut({
                          element: 'graph',
                          data: [
                           
                            {value: <?php echo e((array_key_exists('Femenino', $count_per_gender) ? $count_per_gender['Femenino'] : 0)); ?>, label: 'Mujeres', formatted: 'approx <?php echo e((array_key_exists('Femenino', $count_per_gender) ? ($count_per_gender['Femenino']/$total)*100 : 0)); ?>%' },
                            {value: <?php echo e((array_key_exists('Masculino', $count_per_gender) ? $count_per_gender['Masculino'] : 0)); ?>, label: 'Hombres', formatted: 'approx <?php echo e((array_key_exists('Masculino', $count_per_gender) ? ($count_per_gender['Masculino']/$total)*100 : 0)); ?>%' },
                            {value: <?php echo e((array_key_exists('Otro', $count_per_gender) ? $count_per_gender['Otro'] : 0)); ?>, label: 'Otro', formatted: 'approx <?php echo e((array_key_exists('Otro', $count_per_gender) ? ($count_per_gender['Otro']/$total)*100 : 0)); ?>%' }
                          ],
                          formatter: function (x, data) { return data.formatted; }
                        });
                        </pre>
                        <?php endif; ?>
                        
                        
                    </div>
                    </div>
                </div>
                <?php $__env->stopSection(); ?>
             
<?php echo $__env->make('statistics.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>