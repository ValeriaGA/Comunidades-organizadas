<div id="responsive-modal_<?php echo e($report->id); ?>" class="modal" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true" style="display: none;">
    <div class="modal-dialog" style="left:-20%;width:80%;top:10%;">
        <div class="modal-content">
            <div class="modal-body">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                <div id="myModalCarousel_<?php echo e($report->id); ?>" class="carousel slide" data-ride="carousel">

				  <!-- Wrapper for slides -->
				  <div class="carousel-inner">
				  	<?php $__currentLoopData = $report->evidence; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $modal_evidence): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<?php if($modal_evidence->evidenceType->name == 'Imagen'): ?>
							<div class="item <?php echo e($loop->first ? 'active' : ' '); ?>">
						      <img src="<?php echo e(asset('evidence/'.$report->id.'/'.$modal_evidence->multimedia_path)); ?>" alt="$modal_evidence->multimedia_path">
						    </div>
						<?php endif; ?>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				  </div>

				  <!-- Left and right controls -->
				  <a class="left carousel-control" href="#myModalCarousel_<?php echo e($report->id); ?>" data-slide="prev">
				    <span class="glyphicon glyphicon-chevron-left"></span>
				    <span class="sr-only">Previous</span>
				  </a>
				  <a class="right carousel-control" href="#myModalCarousel_<?php echo e($report->id); ?>" data-slide="next">
				    <span class="glyphicon glyphicon-chevron-right"></span>
				    <span class="sr-only">Next</span>
				  </a>
				</div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-default waves-effect" data-dismiss="modal">Cerrar</button>
            </div>
        </div>
    </div>
</div>

<div id="myCarousel_<?php echo e($report->id); ?>" class="carousel slide" data-ride="carousel">

  <!-- Wrapper for slides -->
  <div class="carousel-inner">
  	<?php $__currentLoopData = $report->evidence; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $evidence): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<?php if($evidence->evidenceType->name == 'Imagen'): ?>
			<div class="item <?php echo e($loop->first ? 'active' : ' '); ?>">
		      <img src="<?php echo e(asset('evidence/'.$report->id.'/'.$evidence->multimedia_path)); ?>" alt="$evidence->multimedia_path" data-toggle="modal" data-target="#responsive-modal_<?php echo e($report->id); ?>">
		    </div>
		<?php endif; ?>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </div>

  <!-- Left and right controls -->
  <a class="left carousel-control" href="#myCarousel_<?php echo e($report->id); ?>" data-slide="prev">
    <span class="glyphicon glyphicon-chevron-left"></span>
    <span class="sr-only">Previous</span>
  </a>
  <a class="right carousel-control" href="#myCarousel_<?php echo e($report->id); ?>" data-slide="next">
    <span class="glyphicon glyphicon-chevron-right"></span>
    <span class="sr-only">Next</span>
  </a>
</div>